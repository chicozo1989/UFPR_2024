
#Reabrir o Dataset

data=read.csv("dados.csv")

#Vamos filtrar os dados para manter apenas os dados de um municipio
natal=subset(data,data$mun_nome=="NATAL")

#5. Medidas de Dispersão-------------------------------------------------------
#Histograma
hist(natal$temperatura_c)
#Raiz quadrada das observações
sqrt(6938)
#Histograma melhor apresentado
hist(natal$temperatura_c, main = "Histograma Temperatura",xlab = "Temperatura",ylab="Frequência", col = "blue",breaks=83)
abline(v=26.39,lwd=3, col="green")
abline(v=26.5,lwd=3,col="orange")
abline(v=27.35,lwd=5,col="black")
legend("topright",abline,lwd=3, col=c("green","orange","black"),legend=c("Média","Mediana","Moda"),bty="n")

#Vamos verificar a normalidade pelo teste de Shapiro-Wilk
#Instalar e habilitar pacotes
install.packages("nortest")
library(nortest)
#Rodar e visualizar o teste
teste=shapiro.test(natal$temperatura_c)
teste
##Aparentemente a temperatura não tem uma distribuição normal.
#Concluímos que não pressuposto de linearidade nesta varíavel

#Calcular Variância
var(data$temperatura_c)
#Calcular Desvio Padrão
sd(data$temperatura_c)


#6.Medidas de Relação--------------------------------------------

#Calcular Correlação de Pearson
cor.test(data$temperatura_c,data$umidade_relativa_percentual,method='pearson')
#Calcular Correlação de Spearman
cor.test(data$temperatura_c,data$umidade_relativa_percentual,method='spearman')
#Calcular Correlação de Kendall
cor.test(data$temperatura_c,data$umidade_relativa_percentual,method='kendall')

#Vamos plotar um diagrama de Dispersão simples
install.packages("ggplot2")
library(ggplot2)
##Usando a função ggplot podemos observar a relação gráfica entre as variáveis
ggplot(data, aes(y = temperatura_c, x = umidade_relativa_percentual)) +
  geom_point(shape = 1, size = 0.5,color="red",fill="red")+
  xlab("Umidade Relativa do Ar(%)")+
  ylab("Temperatura do Ar (°C)")

##Plotar Scatterplot de correlações
#Instalar e abrir pacote "PerformanceAnalytics
install.packages("PerformanceAnalytics")
library(PerformanceAnalytics)
#Plotar Scatterplot
chart.Correlation(data[, 10:19], histogram = TRUE, pch = "+")

#Teste de Tendencia----------------------------------------------------------------------
install.packages("Kendall")
library(Kendall)
##Calcular Tendencia estatistica
MannKendall(natal$pm25_ugm3)
##Vamos calcular o ponto de mudança na série pelo Teste de Pettitt
install.packages("trend")
library(trend)
#Vamos tentar rodar o teste
pettitt.test(natal$pm25_ugm3)
#Ele não roda caso tenhamos NA's, será preciso remove-los
natal2=na.omit(natal)
#Vamos aproveitar e mostrar ao R que a coluna Date simboliza uma data
natal2$Date=as.Date(natal2$Date, "%m/%d/%Y")
#Agora sim
pettitt=pettitt.test(natal2$pm25_ugm3)

#Observe a data em que o teste acusa uma mudança  na tendência
print(natal2[['Date']][pettitt$estimate])

#Vamos plotar o momento da quebra
ggplot(data = natal2, mapping = aes(x = Date, y = pm25_ugm3)) +
  geom_line() +
  geom_vline(mapping = aes(xintercept = as.numeric(natal2[['Date']][pettitt$estimate])),
             linetype = 2,
             colour = "red",
             size = 2)


#7 Regressões Lineares ----------------------------------------------------------

#para realizar um teste simples, vamos criar novas variáveis
alt <- c(176, 154, 138, 196, 132, 176, 181, 169, 150, 175)
peso <- c(82, 49, 53, 112, 47, 69, 77, 71, 62, 78)
#Plotagem de dispersão simples
plot(peso,alt)
#Vamos agregar informações com argumentos
plot(peso, alt, pch = 16, cex = 1.3, col = "blue", main = "ALTURA X PESO", xlab = "PESO CORPORAL (kg)", ylab = "ALTURA (cm)")

#Vamos agora rodar um modelo linear
lm(alt ~ peso)

#Plotar uma linha com o modelo linear
abline(98.0054, 0.9528)
#outra forma
plot(peso, alt, pch = 16, cex = 1.3, col = "blue", main = "ALTURA X PESO", xlab = "PESO CORPORAL (kg)", ylab = "ALTURA (cm)")
abline(lm(alt ~ peso))

#vamos analisar outros parâmetros do modelo
modelo=lm(alt~peso)
summary(modelo)

#Calculo básico -> Primeira variável =Y Segunda variável = X
modelo=lm(natal2$umidade_relativa_percentual ~ natal2$temperatura_c)
#Informações do Modelo
summary(modelo)
#Vamos extrair o valor modelado e compara-lo com os reais
df1.Temp = as.data.frame(modelo$fitted)
df1=cbind(alt,df1.Temp)
colnames(df1) = c("Altura","Modelada")
df1$erro=df1$Altura - df1$Modelada
#Agora o calculo do erro quadrático
df1$erroq=df1$erro^2
eqm=mean(df1$erroq)
sqrt(eqm)

#Regress?o Linear Multipla
modelom=lm(data$pm25_ugm3 ~ data$temperatura_c + data$precipitacao_mmdia + data$umidade_relativa_percentual + data$vento_velocidade_ms)
summary(modelom)

# Regress?o Aditiva Generalizada (GAM)----------------------------------------------------------------
install.packages("mgcv")
library(mgcv)
modelogam=gam(data$pm25_ugm3 ~ data$temperatura_c + data$precipitacao_mmdia + data$umidade_relativa_percentual + data$vento_velocidade_ms)
summary(modelogam)

